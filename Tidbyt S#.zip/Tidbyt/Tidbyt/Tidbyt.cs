﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Http;

namespace Tidbyt_Integration
{
	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Tidbyt
	{
		#region Declarations
		private static HttpServer Server;
		private static bool Server_Running = false;
		private static Debug_Options Debug;
		private static string Processor_IP;
		private static int Processor_Port;
		private static int Temperature = 0;
		private static int Setpoint = 0;
		private static string Mode = "NA";
		#endregion

		//****************************************************************************************
		// 
		//  Tidbyt	-	Default Constructor
		// 
		//****************************************************************************************
		public Tidbyt()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Processor_IP, short Processor_Port, short Debug)
		{
			#region Save Parameters
			Tidbyt.Processor_IP = Processor_IP;
			Tidbyt.Processor_Port = Processor_Port;
			#endregion

			Set_Debug_Message_Output(Debug);

			#region Create Server for capturing responses from Tidbyt Devices
			if (Server_Running == false)                                        //don't create server if already running
			{
				if (Create_Server(Processor_IP, Processor_Port) == false)
				{
					Debug_Message("Initialize", "Create Server Failed");
					return 0;
				}
			}
			#endregion

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Create_Server	-	Setup http server to receive status messages from Tidbyt devices
		// 
		//****************************************************************************************
		private bool Create_Server(string Processor_IP, int Processor_Port)
		{
			try
			{
				//Create a new instance of a server
				Server = new HttpServer();
				//Set the server's IP address
				Server.ServerName = Processor_IP;
				//Set the server's port
				Server.Port = Processor_Port;
				//Assign an event handling method to the server
				Server.OnHttpRequest += new OnHttpRequestHandler(HTTPRequestEventHandler);
				Server.Active = true;
				//save that server is running so initialization can possibly be run again to get device status
				Server_Running = true;
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Tidbyt - Create_Server - Can't create http server: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Tidbyt - Create_Server - Can't create http server: " + e + "\n");
				Server.Active = false;
				return false;
			}

			return true;
		}

		//****************************************************************************************
		// 
		//  HTTPRequestEventHandler	-	Handler to receive messages Get requests from
		//								Tidbyt devices and pass back HAVC info in the
		//								form of JSON
		// 
		//****************************************************************************************
		private void HTTPRequestEventHandler(Object sender, OnHttpRequestArgs requestArgs)
		{
			//Get IP Address of Tidbyt device that sent message
			string Device_IP = requestArgs.Connection.RemoteEndPointAddress;
			Debug_Message("HTTPRequestEventHandler", "Device_IP = " + Device_IP);
			Debug_Message("HTTPRequestEventHandler", "RequestType = " + requestArgs.Request.Header.RequestType.ToString());

			if (requestArgs.Request.Header.RequestType.ToString() == "GET")
			{
				double t = Temperature;
				t = Math.Round(t / 10, 0);
				double sp = Setpoint;
				sp = Math.Round(sp / 10, 0);

				requestArgs.Response.ContentString = "{\"Temperature\":" + t + ",\"Setpoint\":" + sp + ",\"Mode\":\"" + Mode + "\"}"; 
				requestArgs.Response.Code = 200;
				requestArgs.Response.FinalizeHeader(); 
			}
		}

		//****************************************************************************************
		// 
		//  Update	-	Update HVAC Info
		// 
		//****************************************************************************************
		public void Update(short Temperature, short Setpoint, string Mode)
		{
			Tidbyt.Temperature = Temperature;
			Tidbyt.Setpoint = Setpoint;
			Tidbyt.Mode = Mode;
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Tidbyt.Debug = Debug_Options.None;
					break;

				case 1:
					Tidbyt.Debug = Debug_Options.Console;
					break;

				case 2:
					Tidbyt.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Tidbyt.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Tidbyt - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Tidbyt - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

	}
}
